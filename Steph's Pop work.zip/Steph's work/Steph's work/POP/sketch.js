var diam1 = 0;

function setup() {
  createCanvas (600,600);
    background("#006459");
}

function draw() {
    
  background("#EC7063"); 
  fill("#add8e6");
  stroke("#ffff00");
  strokeWeight(1);
  ellipse(50,100,diam1,diam1);
    Diam1=diam1+4;
  fill ("#ff0000");
  ellipse(560,320,diam1,diam1);
    Diam1=diam1+4;
  fill ("#ff0000");
  ellipse(280,452,diam1,diam1);
    Diam1=diam1+4;
  fill ("#add5b5");
  ellipse(180,241,diam1,diam1);
    Diam1=diam1+4;
  fill("#004821");
  ellipse(320,52,diam1,diam1)
    Diam1=diam1+4;
     fill ("#ff0000");
  ellipse(500,290,diam1,diam1);
    Diam1=diam1+4;
     fill ("#ff0000");
  ellipse(205,401,diam1,diam1);
    Diam1=diam1+4;
     fill ("#ff0000");
  ellipse(60,585,diam1,diam1);
    Diam1=diam1+4;
      fill("#004821");
  ellipse(mouseX,mouseY,20,20);
    Diam1=diam1+4;
     fill ("#ff0000");
  ellipse(10,352,diam1,diam1);
    Diam1=diam1+4
    fill("#add8e6");
    ellipse(50,341,diam1,diam1);
    Diam1=diam1+4;
      fill("#004821");
    ellipse(305,151,diam1,diam1);
    Diam1=diam1+4;
    fill("#add8e6");
    ellipse(245,351,diam1,diam1);
    Diam1=diam1+4;
    fill("#add8e6");
    ellipse(235,501,diam1,diam1);
    Diam1=diam1+4;
      fill("#004821");
    ellipse(589,156,diam1,diam1);
    Diam1=diam1+4;
     fill ("#ff0000");
    ellipse(355,581,diam1,diam1);
    Diam1=diam1+4;
    fill("#add8e6");
    ellipse(573,200,diam1,diam1);
    Diam1=diam1+4;
      fill("#004821");
    ellipse(555,458,diam1,diam1);
    Diam1=diam1+4;
     fill ("#ff0000");
    ellipse(205,60,diam1,diam1);
    Diam1=diam1+4;
      fill("#004821");
    ellipse(169,515,diam1,diam1);
    Diam1=diam1+4;
     fill ("#ff0000");
    ellipse(35,401,diam1,diam1);
    Diam1=diam1+4;
      fill("#004821");
    
    
  textSize(20);
  textFont("Verdana");
  textStyle(BOLD);
  textAlign(CENTER);
  text("POP!",300,300);
  console.log(diam1);
}


function mousePressed() {
    if(diam1>250){
        diam1=0;
    }else{
    diam1=diam1+25;
    }
}